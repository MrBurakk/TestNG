package day1;

import org.testng.annotations.Test;
import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class module1 {
	
  @Test(enabled=false)
  public void test1() {  //first test case
	  System.out.println("hello javaTpoint!");
  }
  
  @Test
  public void test2() {  //second test case
	  System.out.println("JTP Travels");
  }
  
  
}
