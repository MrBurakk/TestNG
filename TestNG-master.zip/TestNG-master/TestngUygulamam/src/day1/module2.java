package day1;

import org.testng.annotations.Test;
import org.testng.annotations.Test;

public class module2 {
 
	 @Test
	  public void WebLoginCarLoad() {  //first test case
		  System.out.println("WebLoginCarLoad");
	  }
	  
	  @Test
	  public void MobileLoginCarLoad() {  //second test case
		  System.out.println("MobileLoginCarLoad");
	  }
	  
	  @Test
	  public void APILoginCarLoad() {  //third test case
		  System.out.println("APILoginCarLoad");
	  }
	  
	  
	}