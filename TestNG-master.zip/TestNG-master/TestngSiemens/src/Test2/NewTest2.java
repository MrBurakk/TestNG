package Test2;

import org.testng.annotations.Test;
import static org.testng.Assert.assertEquals;



public class NewTest2 {
	
  @Test
  public void test4() {
	 assertEquals(10,10);
  }
}
